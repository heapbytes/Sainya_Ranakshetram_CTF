import json
def reverse_fun():
	with open("users.json","rb") as f:
		data = f.read()
	try:
		d = json.loads(data)
		return d
	except:
		return 'Illegal Activity Detected ( CMD injection )'
if __name__ == '__main__':
      print(reverse_fun())
